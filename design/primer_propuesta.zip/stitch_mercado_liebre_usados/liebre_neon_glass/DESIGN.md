# Design System Document

## 1. Overview & Creative North Star

### The Creative North Star: "The Electric Curator"
In a world of cluttered, loud marketplaces, this design system serves as a sophisticated lens that filters noise into signal. We aren't building just another "app"; we are building a high-end digital gallery for second-hand treasures. 

The aesthetic is driven by a concept we call **"The Electric Curator."** It combines the cold, architectural precision of deep-space minimalism with the high-energy pulse of neon light. We break away from the "template" look by using intentional asymmetry—letting the product imagery breathe in oversized containers—and utilizing a high-contrast typography scale that feels more like a premium editorial magazine than a standard e-commerce grid. Overlapping elements and glass surfaces create a sense of tangible luxury, where the UI feels like a physical layer hovering over an infinite dark void.

---

## 2. Colors & Surface Logic

Our palette is rooted in the depth of absolute darkness, punctuated by electric highlights that guide the eye toward action and value.

### Tonal Foundations
- **Background (`#0e0e0f`):** The canvas. It is a deep, immersive black that allows the Neon accents to pop.
- **Surface Hierarchy:** 
    - **Surface-Container-Lowest (`#000000`):** Use for inset areas or deep backgrounds.
    - **Surface-Container-Low (`#131314`):** Standard section background.
    - **Surface-Container-High (`#201f21`):** Use for elevated elements like cards or navigation bars.
    - **Surface-Bright (`#2c2c2d`):** Reserved for interactive hover states or highlighted sections.

### Accent Energy
- **Primary (`#81ecff`):** Electric Blue. Used for the most critical actions and brand markers.
- **Secondary (`#ac89ff`):** Neon Purple. Used for secondary actions and "Used" status indicators.
- **Tertiary (`#ff59e3`):** Cyber Pink. Used sparingly for promotional highlights or rare items.

### The Rules of Engagement
- **The "No-Line" Rule:** Prohibit the use of 1px solid borders for sectioning. Boundaries must be defined solely through background color shifts or subtle tonal transitions. A section should end and another begin simply by moving from `surface` to `surface-container-low`.
- **The "Glass & Gradient" Rule:** To provide "soul," primary CTAs and floating headers should utilize a subtle gradient (transitioning from `primary` to `primary_container`).
- **Signature Textures:** Apply a `backdrop-filter: blur(20px)` to any element using a semi-transparent `surface_variant` or `surface_container_high` color. This creates the signature "Glassmorphism" effect, allowing the deep background tones to bleed through softly.

---

## 3. Typography

The typography strategy relies on the tension between the geometric precision of **Space Grotesk** and the humanistic clarity of **Manrope**.

- **Display & Headlines (Space Grotesk):** Used for large price points, product titles, and hero statements. It feels architectural and modern. 
    - *Usage:* `display-lg` (3.5rem) should be used for marquee product names with negative letter-spacing (-2%).
- **Body & Titles (Manrope):** Used for descriptions, specifications, and metadata. It provides a sophisticated editorial feel that balances the "tech" vibe of the neon accents.
- **Labeling:** Small labels (e.g., `label-sm` at 0.6875rem) should be set in all caps with increased letter spacing (0.05em) to convey a sense of "technical spec" authority.

---

## 4. Elevation & Depth

We eschew traditional drop shadows for a more modern, light-based "Tonal Layering" system.

- **The Layering Principle:** Depth is achieved by stacking surface tiers. A `surface-container-highest` card sitting on a `surface` background provides all the "lift" needed without artificial shadows.
- **Ambient Shadows:** For floating elements (like the Logo or FABs), use extra-diffused shadows. 
    - *Specs:* `0px 20px 40px rgba(0, 0, 0, 0.4)` mixed with a subtle glow of the `primary` color at 5% opacity.
- **The "Ghost Border":** If a container requires definition against a similar background, use a "Ghost Border." Use the `outline_variant` token at 15% opacity. **Never use 100% opaque borders.**
- **The Rabbit Logo Integration:** The logo ({{DATA:IMAGE:IMAGE_1}}) should be treated as a "Stamp of Quality." It should live in a glassmorphic container or appear as a subtle, large-scale watermark in the background of profile pages to anchor the brand identity.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `DEFAULT` (0.5rem) roundedness. No border. Text is `on_primary_fixed`.
- **Secondary:** Transparent background with a `primary` Ghost Border (20% opacity). Text in `primary`.
- **Tertiary:** Text only in `secondary`, with a subtle underline on hover.

### Cards (The Product Gallery)
- **Architecture:** Cards must not have borders or dividers.
- **Visuals:** Images should take up the full width of the card. Below the image, use vertical white space (1.5rem) to separate the title from the price. 
- **Effect:** Use `surface-container-high` with a subtle 10% opacity `primary` inner-glow (1px) on the top edge to simulate light hitting the glass.

### Input Fields
- **Default State:** Background `surface_container_lowest`, no border, `md` (0.75rem) roundedness.
- **Active/Focus State:** A 1px Ghost Border using the `primary` color and a subtle outer glow (4px blur).
- **Labels:** Use `label-md` in `on_surface_variant` positioned strictly above the field, never inside.

### Selection Chips
- Use `full` roundedness (Pill shape).
- Unselected: `surface_container_high`.
- Selected: `secondary_container` with `on_secondary_container` text.

---

## 6. Do's and Don'ts

### Do
- **Do** use negative space aggressively. Minimalism requires room to breathe.
- **Do** use the rabbit logo in high-contrast situations (white on deep black).
- **Do** favor vertical rhythm over horizontal lines to separate content.
- **Do** ensure neon text has sufficient contrast against dark backgrounds for accessibility.

### Don't
- **Don't** use 1px solid lines to separate list items; use `surface-container` shifts or 16px of vertical spacing.
- **Don't** use bright backgrounds. This is a "Dark Mode Default" system; any light surface must be an intentional, temporary overlay.
- **Don't** use standard "system" shadows. If an element doesn't feel like it's floating on a bed of light, it's too heavy.
- **Don't** use more than two neon accent colors in a single view. Keep the focus on the product.